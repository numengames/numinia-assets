#!/usr/bin/env bash
# arrancar.sh — arranca este mundo SIN Docker, con tu Node (24 o más). Baja el motor dev (versión
# motor-d2a27eb de GitHub), comprueba su sha256 contra SHA256SUMS, lo desempaqueta en .motor/ (dentro de esta carpeta)
# y lo arranca sobre esta carpeta: abre http://localhost:8790
#   PORT=8791 bash arrancar.sh       otro puerto
#   HOST=0.0.0.0 bash arrancar.sh    que entren otros aparatos de tu red (por defecto, solo este ordenador)
#   MOTOR_DESCARGA=<url o file:///carpeta>  de dónde bajar instalar-motor.sh y SHA256SUMS (un espejo, una prueba)
set -euo pipefail
MUNDO=$(cd "$(dirname "$0")" && pwd)
CORTO=d2a27eb
COMMIT=d2a27eb6945c69c1da6cd768f708ef6a7190b811
BASE=${MOTOR_DESCARGA:-https://github.com/numengames/numinia-engine/releases/download/motor-$CORTO}
MOTOR="$MUNDO/.motor/$CORTO"
die() { printf 'arrancar: %s\n' "$*" >&2; exit 1; }
command -v node > /dev/null || die "hace falta Node 24 o más (https://nodejs.org), o Docker: docker compose up"
node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 24 ? 0 : 1)' || die "tu Node es $(node --version): hace falta el 24 o más"
if [ ! -f "$MOTOR/listo" ]; then
  command -v curl > /dev/null || die "hace falta curl para bajar el motor"
  tmp="$MUNDO/.motor/bajando-$$"; rm -rf "$tmp"; mkdir -p "$tmp"
  echo "arrancar: bajo el motor $CORTO de $BASE"
  curl -fsSL --retry 3 -o "$tmp/instalar-motor.sh" "$BASE/instalar-motor.sh" || die "no pude bajar instalar-motor.sh de $BASE"
  curl -fsSL --retry 3 -o "$tmp/SHA256SUMS" "$BASE/SHA256SUMS" || die "no pude bajar SHA256SUMS de $BASE"
  if command -v sha256sum > /dev/null; then suma=$(sha256sum "$tmp/instalar-motor.sh" | cut -d' ' -f1); else suma=$(shasum -a 256 "$tmp/instalar-motor.sh" | cut -d' ' -f1); fi
  esperada=$(awk '$2 == "instalar-motor.sh" || $2 == "*instalar-motor.sh" { print $1 }' "$tmp/SHA256SUMS")
  [ -n "$esperada" ] && [ "$suma" = "$esperada" ] || die "instalar-motor.sh no coincide con SHA256SUMS: no lo uso"
  version=$(bash "$tmp/instalar-motor.sh" --version)
  case "$version" in "numinia-engine $CORTO "*) ;; *) die "ese instalador es otro motor ($version), no $CORTO" ;; esac
  bash "$tmp/instalar-motor.sh" --solo-extraer "$tmp/motor" > /dev/null
  grep -q "\"commit\": *\"$COMMIT\"" "$tmp/motor/app/build.json" || die "ese motor no es el commit $COMMIT"
  rm -rf "$MOTOR"; mkdir -p "$MUNDO/.motor"; mv "$tmp/motor" "$MOTOR"; touch "$MOTOR/listo"; rm -rf "$tmp"
  echo "arrancar: comprobado (sha256 $suma) y guardado en .motor/$CORTO"
fi
cd "$MOTOR/app"
echo "arrancar: motor $CORTO sobre $MUNDO → http://localhost:${PORT:-8790}  (Ctrl+C para pararlo)"
MOTOR_MUNDO="$MUNDO" WWW_DIR="$MOTOR/www" PORT=${PORT:-8790} HOST=${HOST:-127.0.0.1} exec node packages/server/src/main.ts
